﻿using System;
using System.Collections.Generic;
using System.Web;

namespace CrebitAdminPanelNew.App_Code
{
    public class common
    {

    }
}